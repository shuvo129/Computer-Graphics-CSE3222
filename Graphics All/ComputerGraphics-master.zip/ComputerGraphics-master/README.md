# ComputerGraphics
![alt text](https://github.com/amanBhawsar/ComputerGraphics/blob/master/questions.jpeg)
